//
//  ContentView.swift
//  Weather
//
//  Created by Arwa Alfuraih on 11/06/2022.
//

import SwiftUI

struct ContentView: View {
    @ObservedObject var weatherVM = WeatherViewModel()
    
    var body: some View {
        ZStack(alignment: .bottom){
            
        VStack(spacing: 0){
            MenuHeaderView(weatherVM: weatherVM)
            ScrollView(showsIndicators: false){
                WeatherView(weatherVM: weatherVM)
                
            }
        }.padding(.top, 45)

        } .background(
            LinearGradient(
                    gradient: Gradient(
                        colors:
                        [
                            Color(red: 0.18, green: 0.50, blue: 0.56),
                            Color.black
                    ])
                                     , startPoint: .topLeading, endPoint: .bottomTrailing))
            .edgesIgnoringSafeArea(.all)
            
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
