//
//  API.swift
//  Weather
//
//  Created by Arwa Alfuraih on 11/06/2022.
//

import Foundation
 

struct API{
    static let key = "1a04b9b819be83868026fe7b46e1ebc1"
    
}
