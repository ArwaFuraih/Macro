//
//  WeatherApp.swift
//  Weather
//
//  Created by Arwa Alfuraih on 11/06/2022.
//

import SwiftUI

@main
struct WeatherApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
